<?php 

	require 'database.php';

	if(isset($_REQUEST['action']))
	{
		$action = $_REQUEST['action'];
		$comId = $_REQUEST['id'];
	
		if($action=='edit')
		{
			$editData = editInfo($comId);

			foreach ($editData as $key => $value)
			{
				$comId 		= $value['id'];
				$name 		= $value['name'];
				$email		 = $value['email'];
				$comment	 = $value['comment'];

			}
		}

		if($action =='delete')
		{	
			$status = deleteComment($comId);
			if($status=='deleted')
			{
				echo '<script>alert("deleted");</script>';
				echo '<script>window.location ="cms.php";</script>';

			}
			else
			{
				echo '<script>alert("'.$status.'");</script>';
			}
		}

	}else{

		$comId = '';
		$name = '';
		$email = '';
		$comment = '';
		
	}
	

	if(isset($_POST['add'])){

		$name   		= $_POST['name'];
		$email    			= $_POST['email'];
		$comment       		= $_POST['comment'];
		
		$comId       	= $_POST['indicator'];
	
		if($comId=='')
		{
			$status = insertComment($name,$email,$comment);
			if($status=='true')
			{
				echo '<script>alert("inserted");</script>';
				echo '<script>window.location ="cms.php";</script>';
			}
			else
			{
				echo '<script>alert("'.$status.'");</script>';
			}
		}

		if($comId !='')
		{
			$status = editComment($name,$email,$comment,$comId);
			if($status=='UPDATED')
			{
				echo '<script>alert("edited");</script>';
				echo '<script>window.location ="cms.php";</script>';
			}
			else
			{
				echo '<script>alert("'.$status.'");</script>';
			}
		}


	}
?>

<html>
<body>

<h1 align="center">CMS</h1>

	<form name="add" method="post" action="cms.php">

	<input type="hidden" name="indicator"  value="<?php echo $comId; ?>"><br>
		<table align="center" width="40%">
			<tr>
				<td><label>Name:</label></td>
				<td><textarea required="required"   name="name"><?php echo $name;?></textarea></td>
			</tr>

			<tr>	
				<td><label>Email:</label></td>
				<td><input required="required" type="text" name="email" value="<?php echo $email;?>" ></td>
			</tr>

			<tr>	
				<td><label>Comment:</label></td>
				<td><input required="required" type="text" name="comment" value="<?php echo $comment;?>"></td>
			</tr>
		</table><br>

			<div align="center">
				<input type="submit"  name="add" value="Save changes">
			</div>
	</form><br>



	<table border="1px" width="100%">
		<th>Name</th>
		<th>Email</th>
		<th>Comment</th>
		<th>Edit</th>
		<th>Delete</th>

	<?php 

		 $comments = comment_maintenance();
		 $table_array=array();
		 if(!empty($comments))
		 { 
			 foreach ($comments as $key => $comments)
			 { 
				$comId = $comments['id'];
				$table = '
					<tr>
						<td>'.$comments["name"].'</td>
						<td>'.$comments["email"].'</td>
						<td>'.$comments["comment"].'</td>
						
						<td><a href="cms.php?action=edit&id='.$comId.'" >edit</a></td>
						<td><a href="cms.php?action=delete&id='.$comId.'" >delete</a></td>

					</tr>';
				echo $table;
			}
		}		
	?>
	</table>
	</body>
</html>
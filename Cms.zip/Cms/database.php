<?php
//Connect to database
function connect($host="127.0.0.1",$username="root",$password="",$database="kohana_posts"){
	$myConnection = new mysqli($host,$username,$password,$database);
	if($myConnection)
	{
		return $myConnection;
		
	}
	else 
	{
		return die("Not Connected to database");
	}
	
}


//Insert questions 

function insertComment($name,$email,$comment){

	$myConnection = connect();	
	
	$query ="INSERT INTO demo(name,email,comment) VALUES ('$name','$email','$comment');";
	if($myConnection->query($query))
	{
		return "true";
	}
	else
	{
		return $myConnection->error;
	}
}



//get/create a table for displaying questions for edit and delete
function comment_maintenance(){

		$myConnection = connect();	

		$sql  = "SELECT * FROM demo";
		$result = mysqli_query($myConnection, $sql);

		$my_questions = array();
		while($row = mysqli_fetch_assoc($result)){
		  $my_questions[] = $row;
		  
		}

		return $my_questions;

}
//get data to edit
function editInfo($comId){

	$myConnection = connect();

	$sql  = "SELECT * FROM demo where id ='$comId' ";
		$edit_info = mysqli_query($myConnection, $sql);

		$info = array();
		while($row = mysqli_fetch_assoc($edit_info)){
		  $info[] = $row;
		  
		}

		return $info;

}

function editComment($name,$email,$comment,$comId){

	$myConnection = connect();	


	$query ="UPDATE  demo SET name = '$name',email = '$email', comment = '$comment' WHERE id = '$comId' ";
	 
	if($myConnection->query($query))
	{
		return "UPDATED";
	}
	else
	{
		return $myConnection->error;
	}
	
}

function deleteComment($comId){

	$myConnection = connect();

	$query ="DELETE FROM demo WHERE id = '$comId' ";
	 
	if($myConnection->query($query))
	{
		return "deleted";
	}
	else
	{
		return $myConnection->error;
	}
	

}



?>
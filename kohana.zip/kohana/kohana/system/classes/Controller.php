<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Controller extends Kohana_Controller {}

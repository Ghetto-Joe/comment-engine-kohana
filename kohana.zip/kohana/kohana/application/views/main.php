<h1><?php echo $title; ?></h1>
<table>
<?php echo $rows; ?>
</table>
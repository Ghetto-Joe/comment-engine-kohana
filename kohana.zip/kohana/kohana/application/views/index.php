<h2>My List of Blog</h2>
<hr/>
<h4><?php echo $member->name; ?></h4>
<h4><?php echo $member->email; ?></h4>
<p><?php echo $member->comment; ?></p>
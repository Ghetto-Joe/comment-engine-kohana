<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kohana</title>
	<meta charset="utf-8">
</head>
<body>
	<?php 
		//print_r($errors);
	?>

<?php echo form::open('Test/bye'); ?>
	<?php 
		echo "<tr>";
		echo "<td>".form::label('name', 'Name: ')."</td>";
		echo "<br>";
		echo "<td>".form::input('name', '')."</td>";
		echo "<br>";
		echo "<td>".form::label('email', 'Email: ')."</td>";
		echo "<br>";
		echo "<td>".form::input('email', '')."</td>";
		echo "</tr>";
		echo "<br>";
		echo "<tr>";
		echo "<td>".form::label('comment', 'Comments: ')."</td>";
		echo "<br>";
		echo "<td>".form::textarea('comment', '')."</td>";
		echo "</tr>";
		echo "<tr>";
		echo "<br>";
		echo "<br>";
		echo "<td colspan='2' align='left'>".form::submit('submit', 'Comment')."</td>";
		echo "</tr>";
	?>
<?php echo form::close(); ?>
</body>
</html>
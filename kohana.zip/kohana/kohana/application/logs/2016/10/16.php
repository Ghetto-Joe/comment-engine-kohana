<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-16 05:09:10 --- CRITICAL: View_Exception [ 0 ]: The requested view 1 could not be found ~ SYSPATH\classes\Kohana\View.php [ 265 ] in C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php:350
2016-10-16 05:09:10 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(350): Kohana_View->set_filename(true)
#1 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(12): Kohana_View->render(true)
#2 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_bye()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php:350
2016-10-16 05:20:57 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: now ~ APPPATH\views\test_content.php [ 9 ] in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:20:57 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\views\test_content.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\k...', 9, Array)
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\k...')
#2 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\k...', Array)
#3 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(12): Kohana_View->render()
#4 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_bye()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:26:53 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: now ~ APPPATH\views\test_content.php [ 9 ] in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:26:53 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\views\test_content.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\k...', 9, Array)
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\k...')
#2 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\k...', Array)
#3 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(12): Kohana_View->render()
#4 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_bye()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:27:07 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: now ~ APPPATH\views\test_content.php [ 9 ] in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:27:07 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\views\test_content.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\k...', 9, Array)
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\k...')
#2 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\k...', Array)
#3 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(12): Kohana_View->render()
#4 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_bye()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:27:08 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: now ~ APPPATH\views\test_content.php [ 9 ] in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 05:27:08 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\views\test_content.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\k...', 9, Array)
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\k...')
#2 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\k...', Array)
#3 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(12): Kohana_View->render()
#4 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_bye()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\kohana\kohana\application\views\test_content.php:9
2016-10-16 14:54:41 --- CRITICAL: View_Exception [ 0 ]: The requested view practice/roadtrip could not be found ~ SYSPATH\classes\Kohana\View.php [ 265 ] in C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php:145
2016-10-16 14:54:41 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(145): Kohana_View->set_filename('practice/roadtr...')
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(30): Kohana_View->__construct('practice/roadtr...', NULL)
#2 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(17): Kohana_View::factory('practice/roadtr...')
#3 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_roadtrip()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#9 {main} in C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php:145
2016-10-16 14:56:09 --- CRITICAL: View_Exception [ 0 ]: The requested view practice/roadtrip could not be found ~ SYSPATH\classes\Kohana\View.php [ 265 ] in C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php:145
2016-10-16 14:56:09 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(145): Kohana_View->set_filename('practice/roadtr...')
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php(30): Kohana_View->__construct('practice/roadtr...', NULL)
#2 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(17): Kohana_View::factory('practice/roadtr...')
#3 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_roadtrip()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#6 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#9 {main} in C:\wamp64\www\kohana\kohana\system\classes\Kohana\View.php:145
2016-10-16 14:56:37 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Controller_Test::$practice ~ APPPATH\classes\Controller\Test.php [ 20 ] in C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php:20
2016-10-16 14:56:37 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php(20): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\wamp64\\www\\k...', 20, Array)
#1 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Test->action_roadtrip()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Test))
#4 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\kohana\kohana\application\classes\Controller\Test.php:20
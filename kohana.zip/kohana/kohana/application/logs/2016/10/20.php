<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-20 00:51:46 --- CRITICAL: ErrorException [ 8 ]: Undefined index: default ~ MODPATH\database\classes\Kohana\Database.php [ 65 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 00:51:46 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php(65): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\k...', 65, Array)
#1 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(320): Kohana_Database::instance(NULL)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#4 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:02:44 --- CRITICAL: ErrorException [ 8 ]: Undefined index: default ~ MODPATH\database\classes\Kohana\Database.php [ 65 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:02:44 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php(65): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\k...', 65, Array)
#1 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(320): Kohana_Database::instance(NULL)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#4 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:10:44 --- CRITICAL: ErrorException [ 8 ]: Undefined index: default ~ MODPATH\database\classes\Kohana\Database.php [ 65 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:10:44 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php(65): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\k...', 65, Array)
#1 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(320): Kohana_Database::instance(NULL)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#4 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:11:07 --- CRITICAL: ErrorException [ 8 ]: Undefined index: default ~ MODPATH\database\classes\Kohana\Database.php [ 65 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:11:07 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php(65): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\k...', 65, Array)
#1 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(320): Kohana_Database::instance(NULL)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#4 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:20:02 --- CRITICAL: ErrorException [ 8 ]: Undefined index: default ~ MODPATH\database\classes\Kohana\Database.php [ 65 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:20:02 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php(65): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\k...', 65, Array)
#1 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(320): Kohana_Database::instance(NULL)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#4 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#5 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database.php:65
2016-10-20 01:32:41 --- CRITICAL: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 67 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQL.php:171
2016-10-20 01:32:41 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQL.php(171): Kohana_Database_MySQL->connect()
#1 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_MySQL->list_columns('posts')
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#4 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#5 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#6 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#7 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#11 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQL.php:171
2016-10-20 01:33:35 --- CRITICAL: Database_Exception [ 1146 ]: Table 'comments.posts' doesn't exist [ SHOW FULL COLUMNS FROM `posts` ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php:337
2016-10-20 01:33:35 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php(337): Kohana_Database_MySQLi->query(1, 'SHOW FULL COLUM...', false)
#1 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_MySQLi->list_columns('posts')
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#4 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#5 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#6 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#7 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#8 [internal function]: Kohana_Controller->execute()
#9 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#10 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#12 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#13 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php:337
2016-10-20 01:46:53 --- CRITICAL: Database_Exception [ 2 ]: mysqli::mysqli(): (HY000/1049): Unknown database 'comments' ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 75 ] in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php:154
2016-10-20 01:46:53 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php(154): Kohana_Database_MySQLi->connect()
#1 C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php(337): Kohana_Database_MySQLi->query(1, 'SHOW FULL COLUM...', false)
#2 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_MySQLi->list_columns('posts')
#3 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#4 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#5 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#6 C:\wamp64\www\kohana\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#7 C:\wamp64\www\kohana\kohana\application\classes\Controller\Blog.php(8): Kohana_ORM::factory('Post')
#8 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Controller.php(84): Controller_Blog->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Blog))
#11 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\wamp64\www\kohana\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 C:\wamp64\www\kohana\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in C:\wamp64\www\kohana\kohana\modules\database\classes\Kohana\Database\MySQLi.php:154
2016-10-20 01:53:12 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 01:53:12 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 02:03:02 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 02:03:02 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:03:44 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:03:44 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:05:07 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:05:07 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:05:58 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:05:58 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:06:00 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:06:00 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:07:23 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:07:23 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:07:44 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'mysqli' at 'MODPATH\mysqli' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
2016-10-20 12:07:44 --- DEBUG: #0 C:\wamp64\www\kohana\kohana\application\bootstrap.php(133): Kohana_Core::modules(Array)
#1 C:\wamp64\www\kohana\kohana\index.php(102): require('C:\\wamp64\\www\\k...')
#2 {main} in C:\wamp64\www\kohana\kohana\application\bootstrap.php:133
<?php
defined('SYSPATH') OR die('No direct access allowed.');
class Model_Content extends ORM
{
	protected $_table_name = 'demo';
	protected $_primary_key = 'id';
	
	public function rules(){
		return array(
				'name' => array(
						array('not_empty')
				),
				'email'=> array(
						array('not_empty')
				),
				'comment'=> array(
						array('not_empty')
				)
				
		);
	}
	

}
?>
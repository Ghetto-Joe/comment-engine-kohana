<?php
defined('SYSPATH') or die('No direct script access.');
class Controller_Test extends Controller{
	
	
	public function action_index(){
		$view = View::factory('main');
		$view->title = "Hello, this is the list of users";
		$userlist = "";
		$members = ORM::factory('Content')->find_all();
		
		foreach ($members as $member){
			$detail_view = View::factory('index');
    		$detail_view->name = $member;
    		$detail_view->email = $member;
    		$detail_view->comment = $member;
    		//$userlist .= $detail_view; // .= appends $detail_view to $userlist
		}
		$view->rows = $userlist;
		$this->response->body($view);
	}
	
	public function action_bye()
	{
		//we are rendering a view
		$content = View::factory('test_content')
		->set('values', $_POST);
		
		if($_POST)
		{
			try {
			$member = ORM::factory('Content');
			
			 $member->name	 = $_POST['name'];
		     $member->email 	= $_POST['email'];;
			 $member->comment 	= $_POST['comment'];;
			 $member->save();
			}
			catch (ORM_Validation_Exception $e)
			{
				$errors = $e->errors('model');
			}
		}
		$view = View::factory('test_content')->bind('errors', $errors);
		$this->response->body($content);
	}
	
}
?>
<?php defined('SYSPATH') or die('No direct script access.');

class Kodoc_Property extends Kohana_Kodoc_Property {}

kohana-3.3-mysqli
=================

Kohana 3.3 MySQLi driver

A simple substitution for the original MySQL driver. Just add as a module and set database driver to 'MySQLi'. 
Supports same functionality as the original driver. 

http://tomlankhorst.nl/mysqli-database-driver-for-kohana-3-3/

**Composer**
```
"require": {
    "tomlankhorst/kohana-3.3-mysqli": "dev-master",
}
```
